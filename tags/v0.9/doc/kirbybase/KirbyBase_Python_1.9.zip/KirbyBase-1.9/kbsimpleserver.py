"""Simple single-threaded, blocking database server for KirbyBase.

"""
import SocketServer
import time
import datetime
import cPickle
import cStringIO

from kirbybase import KirbyBase, KBError

host = ''
port = 44444

# Create an instance of the database.
db = KirbyBase('server')

# DBServer class.
class DBServer(SocketServer.BaseRequestHandler):
    # Handler method for client connection.
    def handle(self):
        print "Connected from", self.client_address

        # While client is connected.
        while True:
            # Get client's request length.
            data = self.request.recv(16)

            # If client disconnects, there will be
            # no more data, so break out of loop.
            if not data:
                break

            # Convert data into request length.
            request_length = int(data)

            # Loop to read the request into a StringIO
            data = cStringIO.StringIO()

            while len(data.getvalue()) < request_length:
                data.write(self.request.recv(8192))
            try:
                # Execute client request.
                s = eval(data.getvalue())
            except Exception, errObj:
                # If an exception was raised in KirbyBase, grab
                # the exception instance so we can send it back
                # to the client.
                s = errObj

            # Pickle result of client request in binary format so
            # we can send it across network to client.
            s = cPickle.dumps(s, cPickle.HIGHEST_PROTOCOL)
            
            # Send the length of the result and the result.
            self.request.sendall('%16s%s' % (len(s), s))

        # If client has disconnected, close the connection to
        # client.
        self.request.close()
        print "Disconnected from", self.client_address

# Create new instance of socketserver, and wait
# for connections.
srv = SocketServer.TCPServer((host,port),DBServer)
srv.serve_forever()

