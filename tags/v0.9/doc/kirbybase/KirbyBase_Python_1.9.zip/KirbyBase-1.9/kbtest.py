"""Simple test of kirbybase.

"""
import os
import sys

from kirbybase import KirbyBase, KBError
import datetime

# Uncomment one or the other of next two lines to switch between multiuser
# and embedded.  If multiuser, make sure you have a kbserver running.
db = KirbyBase()
#db = KirbyBase('client', '127.0.0.1', 44444)

# If table exists, delete it.
if os.path.exists('plane.tbl'):
    db.drop('plane.tbl')

# Create a table.
db.create('plane.tbl', ['name:str','country:str','role:str','speed:int',
 'range:int','began_service:datetime.date', 'still_flying:bool'])

# Insert a batch of records.
print db.insertBatch('plane.tbl',[
 ['P-51','USA','Fighter',403,1201,datetime.date(1943,6,24),True],
 ['P-47','USA','Fighter',365,888,datetime.date(1943,3,12),False],
 ['B-17','USA','Bomber',315,1400,datetime.date(1937,5,1),True],
 ['Typhoon', 'Great Britain','Fighter-Bomber',389,690,
 datetime.date(1944,11,20),False],
 ['Sptitfire','Great Britain','Fighter',345,540,datetime.date(1939,2,18),
 True],
 ['Oscar','Japan','Fighter',361,777,datetime.date(1943,12,31),False],
 ['ME-109','Germany','Fighter',366,514,datetime.date(1936,7,7),True],
 ['JU-88','Germany','Bomber',289,999,datetime.date(1937,1,19),False],
 ['P-39','USA','Fighter',None,None,datetime.date(1937,1,18),False]
])

# Insert a record using a dictionary for the input values.
print db.insert('plane.tbl', {'name': 'FW-190', 'country': 'Germany',
 'role': 'Fighter', 'speed': 399, 'range': 499,
 'began_service': datetime.date(1942,12,1), 'still_flying': False})

# Insert a record using an object for the input values.
class Record(object): pass

rec = Record()
rec.name = 'Zero'
rec.country = 'Japan'
rec.role = 'Fighter'
rec.speed = 377
rec.range = 912
rec.began_service = datetime.date(1937,5,15)
rec.still_flying = True
print db.insert('plane.tbl', rec)

# Change all records that have 'Great Britain' in country field to 'England'.
db.update('plane.tbl', ['country'],['Great Britain'],['England'],['country'])

# Now do an update using a dictionary instead of a list.
db.update('plane.tbl', ['recno'],[7],{'speed': 367})

# Now do an update using an object.
rec = Record()
rec.speed = 239
db.update('plane.tbl', ['name'], ['P-39'], rec)

# Delete the FW-190.
db.delete('plane.tbl', ['name'],['FW-190'])

# Remove deleted (i.e. blank) lines from the table.
db.pack('plane.tbl')

# Select all Japanese planes.
print db.select('plane.tbl', ['country'],['Japan'])

print ''

# Select all US planes with a speed greater than 400mph.  When specifiying
# selection criteria against numeric fields, you use python comparison
# expressions (i.e. >,<,==,>=,<=).
print db.select('plane.tbl', ['country','speed'],['USA','>400'])

print ''

# Select all bombers, but not fighter-bombers, using python regular 
# expression syntax. Make sure you set regExp to True.
print db.select('plane.tbl', ['role'],['^Bomber'],useRegExp=True)

print ''

# Select all bombers, but not fighter-bombers, from the USA, using python 
# regular expression syntax. Make sure you set regExp to True.
print db.select('plane.tbl', ['role','country'],['^Bomber','US'],
 useRegExp=True)

print ''

# Select all planes, sorted by country, then speed in descending order 
# (i.e. fastest first). Include only name, country, speed, and range in the 
# result set. Notice how you can request that the return type should be a 
# record object with each field name as an attribute.
results = db.select('plane.tbl', ['recno'],['*'],
 ['name','country','speed','range'], sortFields=['country','speed'],
 sortDesc=['speed'], returnType='object')
for record in results:
    print "Name: %s  Country: %s  Speed: %s  Range: %s" % (record.name, 
     record.country, record.speed, record.range)

print ''

# Select all planes that entered service before January 1st, 1942, sorted
# by the date they began service.
results =  db.select('plane.tbl', ['began_service'],
 ['<%s' % datetime.date(1942,1,1)], sortFields=['began_service'], 
 returnType='dict')
for rec in results:
    print rec['name'], rec['began_service']

print ''

# Select all planes that are still flying.
print db.select('plane.tbl', ['still_flying'],[True])

print ''

# Select all planes.  Specify the returnType as 'report'.  This will format 
# the result set in a nice tabular format, suitable for printing.
print db.select('plane.tbl', ['recno'], ['*'], ['recno','name','country',
 'role'], returnType='report', sortFields=['name'])

print ''

# Set default return type for selects to 'object'.
db.setDefaultReturnType('object')

# Select multiple records by including a list of record numbers.
print db.select('plane.tbl', ['recno'], [[4,6,8]])

# Change the default return type of select queries back to 'list'.
db.setDefaultReturnType('list')

# Get total number of records in plane table.
print 'Total records: ', db.len('plane.tbl')

print ''

# Add a new field to the table called 'bomb_load'.
db.addFields('plane.tbl', ['bomb_load:int'], after='range')

# Update the B-17's record to show that it can haul 8,000 lbs of bombs.
db.update('plane.tbl', ['name'], ['B-17'], {'bomb_load': 8000})

# Prove that it worked.
print db.select('plane.tbl', ['name'], ['B-17'])

# Now, get rid of the field you just added.
db.dropFields('plane.tbl', ['bomb_load'])

