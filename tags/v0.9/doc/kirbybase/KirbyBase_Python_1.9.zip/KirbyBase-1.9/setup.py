from distutils.core import setup

setup(name="KirbyBase",
      version="1.9",
      description="Simple, text-based dbms",
      author="Jamey Cribbs",
      author_email="jcribbs@twmi.rr.com",
      url="http://www.netpromi.com/kirbybase.html",
      py_modules=["kirbybase"]
     )


